█▀▀█ █░░█ █▀▀▄ █░░ ░▀░ █▀▀   █░░ █▀▀█ █▀▀▀ ░▀░ █▀▀ █▀▄▀█ █▀▀█ █▀▀▄ ░▀░ ▀▀█▀▀ █▀▀█ █▀▀█   ▀▀█▀▀ █▀▀█ █▀▀█ █░░█ █▀▀▄ █░░ █▀▀ █▀▀ █░░█ █▀▀█ █▀▀█ ▀▀█▀▀ █▀▀ █▀▀█
█░░█ █░░█ █▀▀▄ █░░ ▀█▀ █░░   █░░ █░░█ █░▀█ ▀█▀ █░░ █░▀░█ █░░█ █░░█ ▀█▀ ░░█░░ █░░█ █▄▄▀   ░░█░░ █▄▄▀ █░░█ █░░█ █▀▀▄ █░░ █▀▀ ▀▀█ █▀▀█ █░░█ █░░█ ░░█░░ █▀▀ █▄▄▀
█▀▀▀ ░▀▀▀ ▀▀▀░ ▀▀▀ ▀▀▀ ▀▀▀   ▀▀▀ ▀▀▀▀ ▀▀▀▀ ▀▀▀ ▀▀▀ ▀░░░▀ ▀▀▀▀ ▀░░▀ ▀▀▀ ░░▀░░ ▀▀▀▀ ▀░▀▀   ░░▀░░ ▀░▀▀ ▀▀▀▀ ░▀▀▀ ▀▀▀░ ▀▀▀ ▀▀▀ ▀▀▀ ▀░░▀ ▀▀▀▀ ▀▀▀▀ ░░▀░░ ▀▀▀ ▀░▀▀

█▀▀ █▀▀▄ █▀▄▀█ █▀▀█
▀▀█ █░░█ █░▀░█ █░░█
▀▀▀ ▀░░▀ ▀░░░▀ █▀▀▀

$Destination="8.8.8.8"
$CommunityString="logicmonitor"
#ping $destination
#tracert $destination
#test-netconnection $destination -port 161

# Hardware SNMP Query
$SNMP = New-Object -ComObject olePrn.OleSNMP
$snmp.open($destination,$CommunityString,2,1000)
$snmp.get('.1.3.6.1.2.1.1.2.0')

# Tree Search SNMP Query
$SNMP = New-Object -ComObject olePrn.OleSNMP
$snmp.open($destination,$CommunityString,2,1000)
$SNMP.GetTree(".1.3.6.1.2.1.2.2.1.2")
 
# Uptime SNMP Query
$SNMP = New-Object -ComObject olePrn.OleSNMP
$snmp.open($destination,$CommunityString,2,1000)
$RESULT = [TimeSpan]::FromSeconds(($SNMP.Get(".1.3.6.1.2.1.1.3.0"))/100)
$SNMP.Close()
$RESULT

# Tree Search to Grid with OID;'s
$SNMP = New-Object -ComObject olePrn.OleSNMP
$snmp.open($destination,$CommunityString,2,1000)
$SNMPDATA=$SNMP.GetTree(".1.3.6.1.2.1.2.2.1.2")
$RESULT=@()
for($i=0;$i-lt $SNMPDATA.length/2;$i++){$RESULT+=[pscustomobject]@{"SNMP ID"=$SNMPDATA[0,$i];"SNMP Value"=$SNMPDATA[1,$i];OID=($snmp.OIDFromString(($SNMPDATA[0,$i])) -join ".")} }
$RESULT | out-gridView

# Troubleshoot SNMP 
Get-ChildItem -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\SNMP\Parameters' -Recurse
$SNMP = New-Object -ComObject olePrn.OleSNMP
$snmp.open($destination,$CommunityString,2,1000)
$snmp.get('.1.3.6.1.2.1.1.1.0')

# Hardware SNMP Query
# $SNMP = New-Object -ComObject olePrn.OleSNMP
# $snmp.open('sc-lon1-vh01','public',2,1000)
# $snmp.get('.1.3.6.1.2.1.1.2.0')

█▀▀▄ █▀▀█ █▀▀▄ ░ █▀▀▄ █▀▀█ █▀▄▀█ █▀▀█ ░▀░ █▀▀▄   █▀▀█ █▀▀▄ █▀▀▄   █░░█ █▀▀█ █▀▀   ░▀░ █▀▀ █▀▀ █░░█ █▀▀ █▀▀
█░░█ █░░█ █░░█ ▀ █░░█ █░░█ █░▀░█ █▄▄█ ▀█▀ █░░█   █▄▄█ █░░█ █░░█   █░░█ █▄▄█ █░░   ▀█▀ ▀▀█ ▀▀█ █░░█ █▀▀ ▀▀█
▀░░▀ ▀▀▀▀ ▀░░▀ ░ ▀▀▀░ ▀▀▀▀ ▀░░░▀ ▀░░▀ ▀▀▀ ▀░░▀   ▀░░▀ ▀░░▀ ▀▀▀░   ░▀▀▀ ▀░░▀ ▀▀▀   ▀▀▀ ▀▀▀ ▀▀▀ ░▀▀▀ ▀▀▀ ▀▀▀

# 1 is ON ; 0 is OFF
get-ItemProperty -Path HKLM:SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableLUA

#Setting UAC via Powershell
Write-Host "UAC is disabled"
Set-ItemProperty -Path HKLM:SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableLUA -Value 1 -Type DWord
Write-Host "Enabling UAC ......Settings will be effective after restart"

Write-Host "UAC is Enabled"
Set-ItemProperty -Path HKLM:SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name EnableLUA -Value 0 -Type DWord
Write-Host "Disabling the UAC......Settings will be effective after restart"

█░░░█ █▀▄▀█ ░▀░   █▀▀ █▀▀█ █░░█ █▀▀▄ ▀▀█▀▀ █▀▀ █▀▀█   █▀▀█ █▀▀ █▀▀█ █▀▀█ ░▀░ █▀▀█
█▄█▄█ █░▀░█ ▀█▀   █░░ █░░█ █░░█ █░░█ ░░█░░ █▀▀ █▄▄▀   █▄▄▀ █▀▀ █░░█ █▄▄█ ▀█▀ █▄▄▀
░▀░▀░ ▀░░░▀ ▀▀▀   ▀▀▀ ▀▀▀▀ ░▀▀▀ ▀░░▀ ░░▀░░ ▀▀▀ ▀░▀▀   ▀░▀▀ ▀▀▀ █▀▀▀ ▀░░▀ ▀▀▀ ▀░▀▀
WMI Counter Repair

REM STAGE 1
REM Registering New Counters & Restoring Default Settings
cd c:\windows\system32
lodctr /R
cd c:\windows\sysWOW64
lodctr /R
winmgmt /clearadap
rem Note: Deprecated for Windows versions post-Windows 2008.
winmgmt /verifyrepository
winmgmt /salvagerepository
winmgmt /resyncperf
sc stop WmiApSrv
sc start WmiApSrv

REM STAGE 2
REM Rebuilding the WMI (CIM) Counter Repository
REM If still having issues, or 0x80041003, “Empty result set” ; “Unexpected WMI query result”, “Expecting size 1, but got size 0” errors.
REM Logged in as an Administrator user, please run the following:

wmiadap /c
wmiadap /f
wmiadap /r
winmgmt.exe /verifyrepository
winmgmt /salvagerepository
winmgmt.exe /resyncperf
sc stop WmiApSrv
sc start WmiApSrv

REM Stage 3
REM Logged in as an Administrator user, please run the following:

REM Change startup type to Window Management Instrumentation (WMI) Service to “Disabled”.
REM Stop the WMI Service; you may need to stop IP Helper Service first or other dependent services before it allows you to stop WMI Service
REM Rename the repository folder: C:\WINDOWS\system32\wbem\Repository to Repository.old
REM Open a CMD Prompt with elevated privileges

cd /d c:\
Pause
CD windows\system32\wbem
Pause
for /f %s in ('dir /b /s *.dll') do regsvr32 /s %s
REM Set the WMI Service type back to Automatic and start WMI Service
REM Go to the root of the c drive, this is IMPORTANT
cd /d c:\ 
Pause
for /f %s in ('dir /s /b *.mof *.mfl') do mofcomp %s

REM You may need to restart IP Helper Service first or other dependent services before it allows you to stop WMI Service